"""Android "All files access" helper.

Uses pyjnius (listed in pyproject.toml, so `flet build` bundles it for Android) to
  * check whether the app may use shared storage (/storage/emulated/0/BIN ATLAS), and
  * open the system screen where the user switches that permission on.
Everything degrades gracefully: on a desktop, or if a JNI call fails, nothing is raised.
"""
from __future__ import annotations

import os

ACTION_MANAGE_APP = "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION"   # per-app "All files access"
ACTION_MANAGE_ALL = "android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"       # list of all apps
ACTION_DETAILS = "android.settings.APPLICATION_DETAILS_SETTINGS"                # app info (Android 10 and older)
FLAG_ACTIVITY_NEW_TASK = 0x10000000
WRITE_PERMISSION = "android.permission.WRITE_EXTERNAL_STORAGE"
PERMISSION_GRANTED = 0


def is_android() -> bool:
    return bool(os.environ.get("ANDROID_ROOT")) and os.path.isdir("/system")


def _autoclass():
    from jnius import autoclass          # raises ImportError anywhere but on a device with pyjnius
    return autoclass


def _context(autoclass):
    return autoclass("android.app.ActivityThread").currentApplication()


def sdk_int() -> int:
    try:
        return int(_autoclass()("android.os.Build$VERSION").SDK_INT)
    except Exception:
        return 0


def has_all_files_access():
    """True / False, or None when it cannot be determined. Desktop: True (nothing to ask for)."""
    if not is_android():
        return True
    try:
        ac = _autoclass()
        sdk = int(ac("android.os.Build$VERSION").SDK_INT)
        if sdk >= 30:                                           # Android 11+: special "All files access"
            return bool(ac("android.os.Environment").isExternalStorageManager())
        if sdk >= 23:                                           # Android 6-10: normal storage permission
            return _context(ac).checkSelfPermission(WRITE_PERMISSION) == PERMISSION_GRANTED
        return True                                             # older: granted at install time
    except Exception:
        return None


def open_access_settings() -> bool:
    """Open the screen where the user grants access. True if a screen was launched."""
    if not is_android():
        return False
    try:
        ac = _autoclass()
        intent_cls, uri_cls = ac("android.content.Intent"), ac("android.net.Uri")
        ctx = _context(ac)
        package_uri = uri_cls.parse("package:" + str(ctx.getPackageName()))
        sdk = int(ac("android.os.Build$VERSION").SDK_INT)
        attempts = []
        if sdk >= 30:
            attempts += [(ACTION_MANAGE_APP, True), (ACTION_MANAGE_ALL, False)]
        attempts.append((ACTION_DETAILS, True))
        for action, with_package in attempts:
            try:
                intent = intent_cls(action, package_uri) if with_package else intent_cls(action)
                intent.addFlags(FLAG_ACTIVITY_NEW_TASK)         # we start it from the application context
                ctx.startActivity(intent)
                return True
            except Exception:
                continue                                        # this phone has no such screen: try the next one
    except Exception:
        pass
    return False
