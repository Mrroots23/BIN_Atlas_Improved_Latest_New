# BIN Atlas v1.4

BIN lookup, issuer search, BIN finder and Luhn practice. Flet 0.28.3 (Python), builds to Android.

## Tabs
- **Lookup** - one or many BINs (comma separated, 6 to 8 digits each). Compact card: Save / Copy / Refresh on one row.
- **Banks** - filters Country > Brand > Bank > Type > Level. Each field opens a dropdown directly under it
  (search box on top, medium-height list you scroll, Close button). Searching with no filter chosen shows
  "Please Select One Section At Least".
  - Country, Brand, Type, Level list everything at once (just scroll).
  - **Bank**: with a country chosen it lists that country's banks ("Show more" for the rest; typing narrows them).
    With no country it lists nothing until you type: 1-2 letters show names that START with them ("J" -> JPMORGAN...),
    3+ letters match anywhere with the "starts with" ones first.
- **Finder** - random BINs from different countries (max 3 per country): quantity (10/25/50/100 or your own, up to 100)
  and card type (Visa / Mastercard / Amex / Mix or any other from the dropdown). No type chosen -> "Select Type Card First".
- **Learn** - multi-number Luhn checker with step-by-step explanation (on-device, nothing stored).
- **Saved** - saved numbers (exactly as searched, up to 8 digits) with notes + history. Export TXT / Clear history are
  pinned above the tab bar. A red trash icon on every BIN deletes just that one (after a confirmation).

## Back button
Closes an open dropdown, or leaves BIN details back to its tab. On a main tab press back twice within 2 s to exit.

## Storage permission
First launch shows a "Permission Required" pop-up. ALLOW opens Android's "All files access" screen for this app
(via pyjnius); the red X closes it. Exporting or importing without access shows the pop-up again every time until it is granted.
TXT files go to `/storage/emulated/0/BIN ATLAS` (fallbacks: Documents/BIN ATLAS, Download/BIN ATLAS, app folder).

## Digits
At most the first 8 digits (the BIN/IIN) are sent, shown, saved or exported. Extra digits are dropped silently.

## Sources and keys
binlist.io -> HandyAPI -> binlist.net with automatic failover. Keys live only on the phone (gear icon).
Use the HandyAPI publishable key (PUB-...); the secret key (HAS-...) is refused.

## Run / test / build
    pip install flet==0.28.3 requests
    python main.py
    python -m unittest test_engine test_ui_smoke test_storage_permission -v
    flet build apk --project "BIN Atlas" --org com.binatlas

## Credits
Offline BIN database: venelinkochev/bin-list-data (CC BY 4.0). Public BIN data may be incomplete or outdated.
